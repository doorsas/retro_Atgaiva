import React, { useState, useCallback } from 'react';
import ImageDropzone from './components/ImageDropzone';
import ComparisonSlider from './components/ComparisonSlider';
import { restoreImage } from './services/gemini';
import { RestorationOptions } from './types';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [restoredImage, setRestoredImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [options, setOptions] = useState<RestorationOptions>({
    colorize: true,
    fixDamage: true,
    enhanceDetails: true,
  });

  const handleImageSelected = useCallback((base64: string) => {
    setOriginalImage(base64);
    setRestoredImage(null);
    setError(null);
  }, []);

  const handleReset = useCallback(() => {
    setOriginalImage(null);
    setRestoredImage(null);
    setError(null);
  }, []);

  const handleRestore = async () => {
    if (!originalImage || isProcessing) return;

    setIsProcessing(true);
    setError(null);

    try {
      const result = await restoreImage(originalImage, options);
      setRestoredImage(result);
    } catch (err: any) {
      setError(err.message || "Nepavyko atkurti nuotraukos. Bandykite dar kartą.");
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleOption = (key: keyof RestorationOptions) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-gray-100 overflow-y-auto no-scrollbar">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gray-950/80 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-900/30">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-white">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">RetroAtgaiva</h1>
          </div>
          {originalImage && (
             <button 
                onClick={handleReset}
                className="text-sm text-gray-400 hover:text-white transition-colors"
                disabled={isProcessing}
             >
                 Pradėti iš naujo
             </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-start p-6 pb-20 w-full max-w-7xl mx-auto">
        
        {/* Error Banner */}
        {error && (
          <div className="w-full max-w-2xl bg-red-500/10 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg mb-6 flex items-start">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
            </svg>
            <span>{error}</span>
          </div>
        )}

        {!originalImage ? (
          <div className="flex flex-col items-center justify-center flex-1 w-full animate-in fade-in zoom-in duration-500">
            <div className="text-center max-w-xl mb-12">
              <h2 className="text-4xl sm:text-5xl font-extrabold text-white mb-6 leading-tight">
                Prikelti senus prisiminimus <br/> naujam gyvenimui.
              </h2>
              <p className="text-lg text-gray-400">
                Automatiškai pataisykite įbrėžimus, paryškinkite neryškias detales ir nuspalvinkite nespalvotas nuotraukas su generatyviniu DI.
              </p>
            </div>
            <ImageDropzone onImageSelected={handleImageSelected} />
            
            {/* Example badges */}
            <div className="mt-12 flex flex-wrap justify-center gap-4 opacity-60">
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-900 border border-gray-800 text-xs font-medium text-gray-300">
                    <span>✨ Triukšmo šalinimas</span>
                </div>
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-900 border border-gray-800 text-xs font-medium text-gray-300">
                    <span>🎨 Spalvinimas</span>
                </div>
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-900 border border-gray-800 text-xs font-medium text-gray-300">
                    <span>🔍 Paryškinimas</span>
                </div>
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-900 border border-gray-800 text-xs font-medium text-gray-300">
                     <span>🤕 Įbrėžimų taisymas</span>
                </div>
            </div>
          </div>
        ) : (
          <div className="w-full flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-500">
            
            {/* Restoration Controls - Sticky if needed, but kept simple here */}
            {!restoredImage && !isProcessing && (
                <div className="w-full max-w-4xl mb-8 p-6 bg-gray-900 rounded-2xl border border-gray-800 shadow-xl">
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-6">
                        <div className="flex flex-wrap justify-center gap-4">
                             <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${options.fixDamage ? 'bg-indigo-600 border-indigo-600' : 'border-gray-600 group-hover:border-gray-500'}`}>
                                    {options.fixDamage && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5 text-white"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>}
                                </div>
                                <input type="checkbox" className="hidden" checked={options.fixDamage} onChange={() => toggleOption('fixDamage')} />
                                <span className="text-gray-300 font-medium">Taisyti pažeidimus</span>
                            </label>

                             <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${options.enhanceDetails ? 'bg-indigo-600 border-indigo-600' : 'border-gray-600 group-hover:border-gray-500'}`}>
                                    {options.enhanceDetails && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5 text-white"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>}
                                </div>
                                <input type="checkbox" className="hidden" checked={options.enhanceDetails} onChange={() => toggleOption('enhanceDetails')} />
                                <span className="text-gray-300 font-medium">Paryškinti detales</span>
                            </label>

                            <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${options.colorize ? 'bg-indigo-600 border-indigo-600' : 'border-gray-600 group-hover:border-gray-500'}`}>
                                    {options.colorize && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5 text-white"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>}
                                </div>
                                <input type="checkbox" className="hidden" checked={options.colorize} onChange={() => toggleOption('colorize')} />
                                <span className="text-gray-300 font-medium">Nuspalvinti</span>
                            </label>
                        </div>

                        <button
                            onClick={handleRestore}
                            className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl shadow-lg shadow-indigo-600/20 transition-all transform active:scale-95 flex items-center justify-center"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 mr-2">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
                            </svg>
                            Atgaivinti nuotrauką
                        </button>
                    </div>
                </div>
            )}

            {/* Image Display Area */}
            <div className="relative w-full max-w-4xl flex justify-center">
              {isProcessing ? (
                <div className="relative w-full max-w-4xl h-[60vh] rounded-xl overflow-hidden bg-gray-900 border border-gray-800 flex items-center justify-center">
                    {/* Background Original Image dimmed */}
                    <img src={originalImage} alt="Originalas" className="absolute inset-0 w-full h-full object-contain opacity-30 blur-sm" />
                    
                    {/* Scanning Effect */}
                    <div className="absolute inset-0 overflow-hidden">
                        <div className="w-full h-1/4 bg-gradient-to-b from-indigo-500/0 via-indigo-500/20 to-indigo-500/0 absolute top-0 animate-scan"></div>
                    </div>

                    <div className="relative z-10 flex flex-col items-center bg-gray-950/70 p-6 rounded-2xl backdrop-blur-md">
                         <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4"></div>
                         <p className="text-lg font-medium text-indigo-300">Atkuriama prisiminimus...</p>
                         <p className="text-sm text-gray-500 mt-2">Tai gali užtrukti kelias sekundes.</p>
                    </div>
                </div>
              ) : restoredImage ? (
                <div className="flex flex-col items-center w-full animate-in fade-in duration-1000">
                    <ComparisonSlider original={originalImage} restored={restoredImage} />
                    <div className="mt-8 flex space-x-4">
                         <a
                            href={restoredImage}
                            download="atkurta-nuotrauka.png"
                            className="px-6 py-3 bg-gray-800 hover:bg-gray-700 text-white font-medium rounded-xl transition-colors flex items-center"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 mr-2">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M7.5 12L12 16.5m0 0L16.5 12M12 16.5V3" />
                            </svg>
                            Atsisiųsti rezultatą
                        </a>
                        <button
                            onClick={() => setRestoredImage(null)}
                            className="px-6 py-3 bg-gray-900 hover:bg-gray-800 text-gray-300 font-medium rounded-xl transition-colors border border-gray-800"
                        >
                            Keisti nustatymus
                        </button>
                    </div>
                </div>
              ) : (
                <div className="relative w-full max-w-4xl h-[60vh] bg-gray-900 rounded-xl overflow-hidden border border-gray-800 shadow-2xl">
                    <img src={originalImage} alt="Peržiūra" className="w-full h-full object-contain" />
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;